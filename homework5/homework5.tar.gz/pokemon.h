/*****************************************************************
//
//  NAME:        River Matsumoto
//
//  HOMEWORK:    5
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:       October 7, 2022
//
//  FILE:       pokemon.h
//
//  DESCRIPTION: the pokemon struct definition.
//
****************************************************************/

struct pokemon
{
    int         level;
    char        name[30];
};
