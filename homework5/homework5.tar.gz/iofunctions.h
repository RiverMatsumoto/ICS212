/*****************************************************************
//
//  NAME:        River Matsumoto
//
//  HOMEWORK:    5
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:       October 7, 2022
//
//  FILE:       iofunctions.h
//
//  DESCRIPTION: the prototypes for the iofunctions.
//
****************************************************************/

int writefile(struct pokemon pokearray[], int num, char filename[]);
int readfile(struct pokemon pokearray[], int* num, char filename[]);
